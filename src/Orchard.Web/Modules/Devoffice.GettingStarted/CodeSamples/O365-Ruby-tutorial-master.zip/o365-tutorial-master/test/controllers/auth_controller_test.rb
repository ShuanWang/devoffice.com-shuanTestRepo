require 'test_helper'

class AuthControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
